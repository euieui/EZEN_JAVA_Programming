package days17;

import java.util.Calendar;

public class zCalendar_Study01 {

	public static void main(String[] args) {
		Calendar a = Calendar.getInstance();
		a.set(2021,7,15);
		System.out.println(a.getTime());

	}

}
