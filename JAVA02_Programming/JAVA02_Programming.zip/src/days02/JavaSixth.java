package days02;

public class JavaSixth {

	public static void main(String[] args) {
		System.out.printf("군사법원의 조직\\권한 및 재판관의");
		System.out.printf("\b\b\b\b\b\b자격은 \"법률\"로 정한다.\n");
		System.out.printf("SQL 명령문에서 \"ABC\"를 포함한 단어를 검색하려면\n");
		System.out.printf("\"%%ABC%%\" 라는 키워드를 사용한다.\n");
	}
}
