package days02;
public class JavaFourth {
	public static void main(String[] args) {
		System.out.printf("\t\t  ###성적표###\n");
		System.out.printf("--------------------------------------------------\n");
		System.out.printf("번호\t성명\t\t국어\t영어\t수학\t총점\t평균\n");
		System.out.printf("--------------------------------------------------\n");
		System.out.printf("1\t홍길동\t\t89\t87\t69\t269\t87.5\n");
		System.out.printf("2\tGildong\t67\t76\t66\t288\t77.5\n");
		System.out.printf("3\tGilbook\t78\t65\t77\t267\t89.5\n");
		System.out.printf("--------------------------------------------------\n");
	}
}
