package days01;

public class JAVA_Second {

	public static void main(String[] args) {
		// 앞선 예제에서 언급한 특정 표시란 : \n (줄바꿈)   
		System.out.printf("겁나 쉬운 프로그래밍~!\n");
		System.out.printf("겁나 쉬운 프로그래밍~!\n");
		System.out.printf("겁나 쉬운 프로그래밍~!\n");
	}

}
